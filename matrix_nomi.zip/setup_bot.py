import json

print("Welcome to the Nomi Matrix Bot Setup Wizard 🧙‍♀️")

config = {
    "nomi_name": input("Enter your Nomi's name (e.g., Aaron): ").strip().lower(),
    "nomi_id": input("Enter your Nomi ID: ").strip(),
    "nomi_api_key": input("Enter your Nomi API Key: ").strip(),
    "matrix_user": input("Enter your Nomi's full Matrix username (e.g., @user:aria.im): ").strip(),
    "matrix_password": input("Enter your Nomi's Matrix password: ").strip(),
    "matrix_homeserver": input("Enter your Matrix homeserver URL (e.g., https://aria.im): ").strip()
}

with open("config.json", "w") as f:
    json.dump(config, f, indent=2)

print("\n✅ Setup complete! You can now run: python nomi_matrix_bot.py")
