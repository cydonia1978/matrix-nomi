import asyncio
import json
from datetime import datetime, timezone
import requests
from nio import AsyncClient, MatrixRoom, RoomMessageText, LoginResponse

# Track the last message ID sent by the bot
last_sent_event_id = None

# ====== Load Config ======
with open("config.json") as f:
    cfg = json.load(f)

NOMI_NAME = cfg["nomi_name"].lower()
NOMI_ID = cfg["nomi_id"]
NOMI_API_KEY = cfg["nomi_api_key"]
MATRIX_USER = cfg["matrix_user"]
MATRIX_PASSWORD = cfg["matrix_password"]
MATRIX_HOMESERVER = cfg["matrix_homeserver"]

# ====== Custom Display Names ======
USERNAME_MAP = {
    "cydonia1978": "Cydonia",
    "rosy.et.argent": "Miu",
    "kehlanistlaurent": "Kehlani",
    "bugbelles": "Janelle",
    "starswept.night": "Heather",
    "queen_pippy": "Pips"
}

# ====== Nomi Chat Function ======
def talk_to_nomi(message, username="Unknown"):
    if len(message) > 560:
        return "TOO_LONG"

    if message.lower().startswith("message from ") and "in matrix:" in message.lower():
        tagged_message = message
    else:
        tagged_message = f"Message from {username} in Matrix:\n{message}"

    url = f'https://api.nomi.ai/v1/nomis/{NOMI_ID}/chat'
    headers = {
        'Authorization': NOMI_API_KEY,
        'Content-Type': 'application/json'
    }
    data = {
        'messageText': tagged_message
    }

    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        return response.json().get('replyMessage', {}).get('text', '')
    else:
        return f"(Error talking to Nomi: {response.status_code})"

# ====== Matrix Bot Setup ======
async def main():
    global last_sent_event_id

    client = AsyncClient(
        MATRIX_HOMESERVER,
        MATRIX_USER
    )

    login_response = await client.login(MATRIX_PASSWORD)

    if not isinstance(login_response, LoginResponse):
        print(f"Login failed: {login_response}")
        return

    print("Login successful.")

    # Save the time the bot started
    startup_time = datetime.now(timezone.utc)

    async def on_message(room: MatrixRoom, event: RoomMessageText):
        global last_sent_event_id

        msg_time = datetime.fromtimestamp(event.server_timestamp / 1000, tz=timezone.utc)
        if msg_time < startup_time:
            return  # Skip old messages

        if event.sender == MATRIX_USER:
            return

        msg = event.body.lower()
        reply_target = event.source.get("content", {}).get("m.relates_to", {}).get("m.in_reply_to", {}).get("event_id", "")

        if NOMI_NAME in msg or reply_target == last_sent_event_id:
            raw_username = event.sender.split(":")[0].lstrip("@")
            display_name = USERNAME_MAP.get(raw_username, raw_username)
            print(f"[{room.display_name}] {display_name}: {event.body}")
            reply = talk_to_nomi(event.body, display_name)

            if reply == "TOO_LONG":
                reply = f"Sorry, but your message didn't send to me! Please send it again with fewer words. ❤️"
                content = {
                    "msgtype": "m.text",
                    "body": reply,
                    "m.relates_to": {
                        "m.in_reply_to": {
                            "event_id": event.event_id
                        }
                    }
                }
            else:
                content = {
                    "msgtype": "m.text",
                    "body": reply
                }

            resp = await client.room_send(
                room_id=room.room_id,
                message_type="m.room.message",
                content=content
            )
            last_sent_event_id = resp.event_id

    client.add_event_callback(on_message, RoomMessageText)
    await client.sync_forever(timeout=30000)

# Run it
asyncio.run(main())
