import asyncio
import json
from datetime import datetime, timezone
import requests
from nio import AsyncClient, MatrixRoom, RoomMessageText, LoginResponse

# ====== Load Config ======
with open("config.json") as f:
    cfg = json.load(f)

NOMI_NAME = cfg["nomi_name"].lower()
NOMI_ID = cfg["nomi_id"]
NOMI_API_KEY = cfg["nomi_api_key"]
MATRIX_USER = cfg["matrix_user"]
MATRIX_PASSWORD = cfg["matrix_password"]
MATRIX_HOMESERVER = cfg["matrix_homeserver"]

# ====== Custom Display Names ======
USERNAME_MAP = {
    "cydonia1978": "Cydonia",
    "starswept": "Heather"
}

# ====== Nomi Chat Function ======
def talk_to_nomi(message, username="Unknown"):
    if len(message) > 1000:
        return "That message is a little too long for me to process all at once. Could you break it into smaller parts?"

    tagged_message = f"Message from {username} in Matrix:\n{message}"

    url = f'https://api.nomi.ai/v1/nomis/{NOMI_ID}/chat'
    headers = {
        'Authorization': NOMI_API_KEY,
        'Content-Type': 'application/json'
    }
    data = {
        'messageText': tagged_message
    }

    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        return response.json().get('replyMessage', {}).get('text', '')
    else:
        return f"(Error talking to Nomi: {response.status_code})"

# ====== Matrix Bot Setup ======
async def main():
    client = AsyncClient(
        MATRIX_HOMESERVER,
        MATRIX_USER
    )

    login_response = await client.login(MATRIX_PASSWORD)

    if not isinstance(login_response, LoginResponse):
        print(f"Login failed: {login_response}")
        return

    print("Login successful.")

    # Save the time the bot started
    startup_time = datetime.now(timezone.utc)

    async def on_message(room: MatrixRoom, event: RoomMessageText):
        msg_time = datetime.fromtimestamp(event.server_timestamp / 1000, tz=timezone.utc)
        if msg_time < startup_time:
            return  # Skip old messages

        if event.sender == MATRIX_USER:
            return

        msg = event.body.lower()
        is_direct_reply = event.source.get("content", {}).get("m.relates_to", {}).get("m.in_reply_to", {}).get("event_id")

        if NOMI_NAME in msg or is_direct_reply:
            raw_username = event.sender.split(":")[0].lstrip("@")
            display_name = USERNAME_MAP.get(raw_username, raw_username)
            print(f"[{room.display_name}] {display_name}: {event.body}")
            reply = talk_to_nomi(event.body, display_name)
            await client.room_send(
                room_id=room.room_id,
                message_type="m.room.message",
                content={"msgtype": "m.text", "body": reply}
            )

    client.add_event_callback(on_message, RoomMessageText)

    await client.sync_forever(timeout=30000)

# Run it
asyncio.run(main())
