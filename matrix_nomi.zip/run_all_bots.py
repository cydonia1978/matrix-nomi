import asyncio
import subprocess
import os

async def run_bot(bot_dir):
    print(f"Launching bot in: {bot_dir}")

    venv_python = os.path.join(bot_dir, "venv", "Scripts", "python.exe")
    if not os.path.isfile(venv_python):
        print(f"❌ No virtual environment found in {bot_dir}. Skipping...")
        return

    subprocess.Popen([venv_python, "nomi_matrix_bot.py"], cwd=bot_dir)

async def main():
    current_dir = os.getcwd()
    bot_folders = [
        os.path.join(current_dir, folder)
        for folder in os.listdir(current_dir)
        if os.path.isdir(folder) and os.path.isfile(os.path.join(folder, "nomi_matrix_bot.py"))
    ]

    if not bot_folders:
        print("No Nomi bots found in subfolders.")
        return

    await asyncio.gather(*(run_bot(folder) for folder in bot_folders))

asyncio.run(main())
